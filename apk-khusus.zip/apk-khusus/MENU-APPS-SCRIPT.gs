/**
 * Sumber daftar menu untuk aplikasi.
 * Cara pakai:
 *  1. Buat Spreadsheet baru, beri nama sheet: "Menu".
 *  2. Baris 1 = judul kolom: title | subtitle | icon | url | open | active
 *  3. Extensions > Apps Script, tempel kode ini, ganti SHEET_ID.
 *  4. Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone.
 *  5. Salin URL /exec, pasang sebagai variabel MENU_URL di GitHub (Settings > Variables).
 *
 * Kolom "open": kosong/webview = buka di dalam aplikasi, browser = buka di browser HP.
 * Kolom "active": FALSE untuk menyembunyikan menu tanpa menghapus barisnya.
 */
const SHEET_ID = 'GANTI_DENGAN_ID_SPREADSHEET';
const SHEET_NAME = 'Menu';

function doGet() {
  const sh = SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);
  const rows = sh.getDataRange().getValues();
  const head = rows.shift().map(h => String(h).trim().toLowerCase());
  const items = rows
    .map(r => {
      const o = {};
      head.forEach((h, i) => (o[h] = r[i]));
      return o;
    })
    .filter(o => String(o.url || '').trim() !== '')
    .filter(o => String(o.active).toUpperCase() !== 'FALSE')
    .map(o => ({
      title: String(o.title || 'Menu'),
      subtitle: String(o.subtitle || ''),
      icon: String(o.icon || '•'),
      url: String(o.url).trim(),
      open: String(o.open || 'webview').trim().toLowerCase()
    }));

  const payload = {
    title: 'APK Khusus',
    hint: 'Pilih layanan yang ingin dibuka',
    footer: 'Pondok Pesantren Urwah Bin Zubair',
    items: items
  };

  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
