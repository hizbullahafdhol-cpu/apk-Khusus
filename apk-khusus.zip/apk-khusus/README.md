# APK Khusus — aplikasi kumpulan link

Aplikasi Android sederhana: isinya hanya daftar menu, tiap menu membuka satu link
(mis. web app Google Apps Script) di dalam aplikasi.

**Daftar menunya diambil dari sebuah link JSON**, jadi menambah/mengubah menu nanti
cukup lewat Spreadsheet/Apps Script — tidak perlu membuat APK baru.

## Isi proyek

| Berkas | Guna |
|---|---|
| `app/src/main/java/.../MainActivity.java` | Seluruh logika aplikasi (menu, WebView, cetak, cek pembaruan) |
| `app/src/main/assets/menu.json` | Menu cadangan (dipakai saat offline / sebelum menu online termuat) |
| `app/src/main/res/values/strings.xml` | Nama aplikasi & teks beranda |
| `app/src/main/res/mipmap-*/` | Logo aplikasi |
| `MENU-APPS-SCRIPT.gs` | Kode Apps Script penyaji daftar menu dari Spreadsheet |
| `.github/workflows/build-apk.yml` | Pembuat APK otomatis di GitHub |

## Langkah pakai (sekali saja)

### 1. Unggah proyek ke GitHub
Buat repo baru (mis. `apk-khusus`), lalu unggah seluruh isi folder ini
(boleh lewat tombol **Add file → Upload files** di GitHub).

### 2. Buat kunci penanda tangan (keystore)
Kunci ini wajib **sama** setiap kali build, supaya aplikasi bisa di-update tanpa uninstall.
Berkas `release.jks` sudah saya sertakan beserta sandinya di catatan terpisah — jangan
diunggah ke repo. Di GitHub: **Settings → Secrets and variables → Actions → New repository secret**:

| Nama secret | Isi |
|---|---|
| `KEYSTORE_BASE64` | isi berkas `release.jks.base64.txt` |
| `KEYSTORE_PASSWORD` | sandi keystore |
| `KEY_ALIAS` | `portal` |
| `KEY_PASSWORD` | sandi kunci |

Di tab **Variables** tambahkan `MENU_URL` = URL `/exec` Apps Script penyaji menu.

### 3. Build APK
- Otomatis setiap kali ada perubahan di branch `main`, atau
- **Actions → Build APK → Run workflow**.

Hasilnya:
- APK bisa diunduh di halaman Actions (bagian *Artifacts*), dan
- kalau Anda membuat tag versi (`v1.0`, `v1.1`, …), APK otomatis terbit di **Releases**
  sehingga tombol pembaruan di dalam aplikasi langsung berfungsi.

### 4. Menambah menu nanti
Cukup tambah baris di Spreadsheet menu. Aplikasi memuat ulang daftar menu setiap kali dibuka.

## Mengubah nama, warna, logo
- Nama aplikasi & teks beranda: `app/src/main/res/values/strings.xml`
- Warna: `app/src/main/res/values/colors.xml`
- Logo: ganti berkas `ic_launcher.png` dan `ic_launcher_foreground.png` di tiap folder `mipmap-*`
- Nama paket (`applicationId`): `app/build.gradle`

## Catatan penting
- Web app Apps Script sebaiknya dideploy dengan akses **Anyone** (tanpa login Google).
  Halaman login Google memang diblokir Google bila dibuka di dalam WebView aplikasi.
  Untuk menu yang butuh login, isi kolom `open` dengan `browser` agar dibuka di Chrome.
- Versi aplikasi diatur di `app/build.gradle` (`versionCode` & `versionName`).
